// import logo from './logo.svg';
// import './App.css';


import Template from "./Template_task/Template"


function App() {
  return (
    <div>

      <Template />
      

    </div>
  )
}

export default App
